<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ActivityLogController extends Controller
{
    public static function store($activity, $object, $object_id, $description)
    {
        $activityLog = new \App\Models\ActivityLog();
        $activityLog->user_id = auth()->user()->id;
        $activityLog->activity = $activity;
        $activityLog->object = $object;
        $activityLog->object_id = $object_id;
        $activityLog->description = $description;
        $activityLog->save();
    }
}
