<?php

namespace App\Http\Controllers;

use App\Models\FinishingBy;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FinishingByController extends Controller
{
    public function index()
    {
        $finishingBys = FinishingBy::all();
        return view('finishing_by.index', compact('finishingBys'));
    }

    public function create()
    {
        return view('finishing_by.create');
    }

    public function show($id)
    {
        $finishingBy = FinishingBy::findOrFail($id);
        return view('finishing_by.show', compact('finishingBy'));
    }

    public function edit($id)
    {
        $finishingBy = FinishingBy::findOrFail($id);
        if (!$finishingBy) {
            return redirect()->back()->with('error', 'Post-Press Subcon not found.');
        }
        return view('finishing_by.edit', compact('finishingBy'));
    }

    public function store(Request $request)
    {
        DB::beginTransaction();

        try {
            $request->validate([
                'name' => 'required|unique:finishing_bies',
                'phone_number' => 'required',
                'description' => 'nullable|array',
                'description.*' => 'nullable|string|max:255',
            ]);

            $finishingBy = FinishingBy::create(['name' => $request->name, 'phone_number' => $request->phone_number]);

            if ($request->filled('description')) {
                $descriptions = array_filter($request->description);
                
                $finishingBy->descriptions()->createMany(
                    array_map(fn($desc) => ['description' => $desc], $descriptions)
                );
            }

            ActivityLogController::store('created', 'post-press subcon', $finishingBy->id, null);

            DB::commit();
            return redirect()->back()->with('success', 'Post-Press Subcon created successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()
                ->with('error', 'Failed to create Post-Press Subcon. ' . $e->getMessage())
                ->withInput();
        }
    }

    public function update(Request $request, $id)
    {
        DB::beginTransaction();

        try {
            $finishingBy = FinishingBy::findOrFail($id);
            
            $request->validate([
                'name' => 'required|unique:finishing_bies,name,' . $id,
                'description' => 'nullable|array',
                'description.*' => 'nullable|string|max:255',
            ]);

            // Update the main record
            $finishingBy->update(['name' => $request->name, 'phone_number' => $request->phone_number]);

            // Handle descriptions - first delete existing ones
            $finishingBy->descriptions()->delete();

            // Add new descriptions if provided
            if ($request->has('description') && is_array($request->description)) {
                foreach (array_filter($request->description) as $desc) {
                    if (!empty($desc)) {
                        $finishingBy->descriptions()->create([
                            'description' => $desc
                        ]);
                    }
                }
            }

            ActivityLogController::store('updated', 'post-press subcon', $finishingBy->id, null);

            DB::commit();
            return redirect()->back()->with('success', 'Post-Press Subcon updated successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()
                ->with('error', 'Failed to update Post-Press Subcon. ' . $e->getMessage())
                ->withInput();
        }
    }

    public function destroy($id)
    {
        try {
            $finishingBy = FinishingBy::findOrFail($id);
            if (!$finishingBy) {
                return redirect()->back()->with('error', 'Post-Press Subcon not found.');
            }

            $finishingBy->delete();

            ActivityLogController::store('deleted', 'post-press subcon', null, $finishingBy->name);

            return redirect()->back()->with('success', 'Post-Press Subcon deleted successfully.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Failed to delete Post-Press Subcon. ' . $e->getMessage());
        }
    }
}
