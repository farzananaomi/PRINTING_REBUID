<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\CustomerPic;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class CustomerPicController extends Controller
{
    public function index($customerId = null)
    {
        // Fetch customer pictures based on the customer ID
        if ($customerId) {
            $pics = CustomerPic::where('customer_id', $customerId)->get();
        } else {
            $pics = CustomerPic::all();
        }

        $customer = Customer::find($customerId);
        if (!$customer) {
            return redirect()->back()->with('error', 'Customer not found.');
        }

        return view('customer_pic.index', compact('pics', 'customer'));
    }    

    public function create($customerId = null)
    {
        // Fetch the customer details
        $customer = Customer::find($customerId);
        if (!$customer) {
            return redirect()->back()->with('error', 'Customer not found.');
        }

        // Pass the customer ID and picture ID to the view
        return view('customer_pic.create', compact('customer'));
    }
   

    public function show($id)
    {
        return view('customer_pic.show', compact('id'));
    }

    public function edit($customerId, $id)
    {
        // Fetch the customer picture details for editing
        $customer = Customer::find($customerId);
        if (!$customer) {
            return redirect()->back()->with('error', 'Customer not found.');
        }
        $pic = CustomerPic::findOrFail($id);
        return view('customer_pic.edit', compact('customer','pic'));
    }

    public function store($customerId, Request $request)
    {
        try {
            // Logic to store customer picture
            $request->validate([
                'pic_name' => 'required',
                'phone_number' => 'required',
                'email' => 'required|email',
            ]);
            $customerPic = new CustomerPic();
            $customerPic->customer_id = $customerId;
            $customerPic->pic_name = $request->pic_name;
            $customerPic->phone_number = $request->phone_number;
            $customerPic->email = $request->email;
            $customerPic->save();
            
            return redirect()->back()->with('success', 'Customer pic created successfully.');
        } catch (\Exception $e) {
            // Log the error
            Log::error('Error creating customer pic: ' . $e->getMessage());
            // Optionally, you can also return an error message to the user
            return redirect()->back()->with('error', 'Failed to create customer pic: ' . $e->getMessage())->withInput();
        }
    }

    public function update($customerId, Request $request, $id)
    {
        // Logic to update customer picture
        try {
            $customerPic = CustomerPic::findOrFail($id);
            if (!$customerPic) {
                return redirect()->back()->with('error', 'Customer picture not found.');
            }
            $request->validate([
               'pic_name' => 'required',
                'phone_number' => 'required',
                'email' => 'required|email',
            ]);
           $customerPic->pic_name = $request->pic_name;
            $customerPic->phone_number = $request->phone_number;
            $customerPic->email = $request->email;
            $customerPic->save();
            // Optionally, you can also return an error message to the user
            return redirect()->back()->with('success', 'Customer picture updated successfully.');
        } catch (\Exception $e) {
            // Log the error
            Log::error('Error updating customer pic: ' . $e->getMessage());
            // Optionally, you can also return an error message to the user
            return redirect()->back()->with('error', 'Failed to update customer pic. Please try again.');
        }
    }

    public function destroy($customerId, $id)
    {
        try {
            // Logic to delete customer picture
            $customerPic = CustomerPic::findOrFail($id);
            if (!$customerPic) {
                return redirect()->back()->with('error', 'Customer picture not found.');
            }
            $customerPic->delete();
            return redirect()->back()->with('success', 'Customer picture deleted successfully.');
        } catch (\Exception $e) {
            // Log the error
            Log::error('Error deleting customer pic: ' . $e->getMessage());
            // Optionally, you can also return an error message to the user
            return redirect()->back()->with('error', 'Failed to delete customer pic. Please try again.');
        }
    }
}
