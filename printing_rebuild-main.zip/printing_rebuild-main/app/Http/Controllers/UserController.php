<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\User;
use Flux\Flux;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class UserController extends Controller
{
    public function index()
    {
        $users = User::all();

        return view('user.index', compact('users'));
    }

    public function create()
    {
        // Generate a new user ID
        $userId = $this->generateUserId();

        // Pass the user ID to the view
        return view('user.create', compact('userId'));
    }

    public function edit($id)
    {
        // Fetch user details for editing
        $user = User::findOrFail($id);
        return view('user.edit', compact('user'));
    }

    public function show($id)
    {
        return view('user.show', compact('id'));
    }

    public function destroy($id)
    {
        try {
            // Logic to delete the user
            $user = User::findOrFail($id);

            // Check if the user is attempting to delete themselves
            if ($user->id == auth()->id()) {
                return redirect()->back()->with('error', 'You cannot delete your own account.');
            }

            $user->delete();
            ActivityLogController::store('deleted', 'user', null, $user->name);
            return redirect()->route('users.index')->with('success', 'User deleted successfully.');

        } catch (\Exception $e) {
            Log::error('User deletion failed: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Failed to delete user. Please try again.');
        }
    }

    public function store(Request $request)
    {
        try {
            // Validate with custom error messages
            $validated = $request->validate([
                'user_id' => 'required|unique:users',
                'name' => 'required|string|max:255',
                'email' => 'required|email|unique:users',
                'password' => 'required|string|confirmed',
                'is_sale_person' => 'sometimes|boolean'
            ], [
                'user_id.required' => 'The user ID field is required.',
                'user_id.unique' => 'This user ID already exists.',
                'name.required' => 'The full name is required.',
                'email.required' => 'The email address is required.',
                'email.unique' => 'This email is already registered.',
                'password.confirmed' => 'Password confirmation does not match.',
                'password.min' => 'Password must be at least 8 characters.'
            ]);

            // Create user with mass assignment protection
            $user = User::create([
                'user_id' => $validated['user_id'],
                'name' => $validated['name'],
                'email' => $validated['email'],
                'password' => bcrypt($validated['password']),
                'is_sale_person' => $request->boolean('is_sale_person')
            ]);

            ActivityLogController::store('created', 'user', $user->id, null);

            return redirect()
                ->route('users.index')
                ->with([
                    'success' => 'User created successfully.',
                    'user_id' => $user->user_id
                ]);

        } catch (ValidationException $e) {
            return redirect()
                ->back()
                ->with('error', 'Unexpected error in user creation: ' . $e->getMessage())
                ->withInput();

        } catch (QueryException $e) {
            Log::error('User creation failed: ' . $e->getMessage());
            
            return redirect()
                ->back()
                ->with('error', 'Database error occurred. Please try again.')
                ->withInput();

        } catch (\Exception $e) {
            Log::critical('Unexpected error in user creation: ' . $e->getMessage());
            
            return redirect()
                ->back()
                ->with('error', 'An unexpected error occurred. Please contact support.')
                ->withInput();
        }
    }
    public function update(Request $request, $id)
    {
     try {
            // Validate the request data
            $validatedData = $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email,'.$id,
                'password' => 'nullable|string|confirmed',
                'is_sale_person' => 'sometimes|boolean'
            ], [
                'name.required' => 'The name field is required.',
                'email.required' => 'The email field is required.',
                'email.email' => 'The email must be a valid email address.',
                'email.unique' => 'The email has already been taken.',
                'password.min' => 'The password must be at least 8 characters.',
                'password.confirmed' => 'The password confirmation does not match.',
            ]);

            // Find the user
            $user = User::findOrFail($id);

            // Update the user's information
            $user->name = $validatedData['name'];
            $user->email = $validatedData['email'];

            // Update the password if provided
            if ($request->filled('password')) {
                $user->password = bcrypt($validatedData['password']);
            }

            // Update the is_sale_person field if provided
            if ($request->filled('is_sale_person')) {
                $user->is_sale_person = $validatedData['is_sale_person'];
            }

            // Save the changes
            $user->save();

            ActivityLogController::store('updated', 'user', $user->id, null); // Call ActivityLogController::store

            // Redirect to the user's profile page with a success message
            return redirect()->route('users.index')
                ->with('success', 'User updated successfully.');

        } catch (ValidationException $e) {
            return redirect()
                ->back()
                ->withErrors($e->errors())
                ->withInput();
        } catch (QueryException $e) {
            Log::error('User update failed: ' . $e->getMessage());
            return redirect()
                ->back()
                ->with('error', 'Database error occurred. Please try again.')
                ->withInput();
        } catch (\Exception $e) {
            Log::critical('Unexpected error in user update: ' . $e->getMessage());
            return redirect()
                ->back()
                ->with('error', 'An unexpected error occurred. Please contact support.')
                ->withInput();
        }
    }

    public function generateUserId()
    {
        // Get the last used ID from database
        $lastUser = User::orderBy('id', 'desc')->first();
        
        // Start from 1 if no users exist
        $nextNumber = $lastUser ? (int) str_replace('FW_', '', $lastUser->user_id) + 1 : 1;
        
        // Format with leading zeros
        return 'FW_' . str_pad($nextNumber, 3, '0', STR_PAD_LEFT);
    }
}
