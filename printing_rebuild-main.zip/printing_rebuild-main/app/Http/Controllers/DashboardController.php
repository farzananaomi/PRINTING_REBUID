<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $activityLogs = ActivityLog::latest()->take(100)->get();
        return view('dashboard', compact('activityLogs'));
    }
}
