<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');
        
        $customers = Customer::when($search, function ($query, $search) {
            return $query->where(function ($q) use ($search) {
                $q->where('company_name', 'like', "%{$search}%")
                  ->orWhere('customer_id', 'like', "%{$search}%")
                  ->orWhere('address', 'like', "%{$search}%")
                  ->orWhere('customer_type', 'like', "%{$search}%");
            });
        })
        ->orderBy('company_name')
        ->paginate(10); // Adjust pagination as needed

        return view('customer.index', compact('customers'));
    }

    public function create()
    {
        $customerId = $this->generateCustId();
        return view('customer.create', compact('customerId'));
    }

    public function show($id)
    {
        return view('customer.show', compact('id'));
    }

    public function edit($id)
    {
        $customer = Customer::findOrFail($id);
        if (!$customer) {
            return redirect()->back()->with('error', 'Customer not found.');
        }

        return view('customer.edit', compact('customer'));
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
            'customer_id' => 'required|unique:customers',
            'company_name' => 'required',
            'address' => 'required',
            'customer_type' => 'required',
            ]);

            $customer = Customer::create($request->all());

            ActivityLogController::store('created', 'customer', $customer->id, null);

            return redirect()->back()->with('success', 'Customer created successfully.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Failed to create customer. ' . $e->getMessage())->withInput();
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $customer = Customer::findOrFail($id);
            if (!$customer) {
                return redirect()->back()->with('error', 'Customer not found.');
            }

            $request->validate([
                'company_name' => 'required',
                'address' => 'required',
                'customer_type' => 'required',
            ]);

            $customer->update($request->all());

            ActivityLogController::store('updated', 'customer', $customer->id, null);

            return redirect()->back()->with('success', 'Customer updated successfully.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Failed to update customer. ' . $e->getMessage())->withInput();
        }
    }

    public function destroy($id)
    {
        try {
            $customer = Customer::findOrFail($id);
            if (!$customer) {
                return redirect()->back()->with('error', 'Customer not found.');
            }

            $customer->delete();

            ActivityLogController::store('deleted', 'customer', null, $customer->name);

            return redirect()->back()->with('success', 'Customer deleted successfully.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Failed to delete customer. ' . $e->getMessage());
        }
    }

    public function generateCustId()
    {
        $lastCustomer = Customer::orderBy('created_at', 'desc')->first();
        $lastId = $lastCustomer ? (int) substr($lastCustomer->customer_id, 5) : 0;
        $newId = 'CUST_' . str_pad($lastId + 1, 5, '0', STR_PAD_LEFT);

        return $newId;
    }
}
