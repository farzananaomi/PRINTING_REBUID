<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class SalesPersonController extends Controller
{
    public function index()
    {
        $users = User::where('is_sale_person','1')->get();
        return view('sales_person.index', compact('users'));
    }

    public function create()
    {
        // Generate a new user ID
        $userId = $this->generateUserId();
        return view('sales_person.create', compact('userId'));
    }

    public function show($id)
    {
        return view('sales_person.show', compact('id'));
    }

    public function edit($id)
    {
        $user = User::findOrFail($id);
        if (!$user) {
            return redirect()->back()->with('error', 'Sales Person not found.');
        }
        return view('sales_person.edit', compact('user'));
    }

    public function generateUserId()
    {
        $lastUser = User::orderBy('id', 'desc')->where('is_sale_person','1')->first();
        $nextNumber = $lastUser ? (int) str_replace('SP', '', $lastUser->user_id) + 1 : 1;
        $newId = $nextNumber;
        return 'SP' . str_pad($newId, 4, '0', STR_PAD_LEFT);
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required|unique:users',
                'name' => 'required',
                'email' => 'required|email|unique:users',
                'password' => 'required',
            ]);

            User::create($request->all());

            return redirect()->back()->with('success', 'Sales Person created successfully.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Failed to create Sales Person. ' . $e->getMessage())->withInput();
        }
    }

    public function update(Request $request, $id)
    {
        try {
            // Validate the request data
            $validatedData = $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email,'.$id,
                'password' => 'nullable|string|confirmed',
            ], [
                'name.required' => 'The name field is required.',
                'email.required' => 'The email field is required.',
                'email.email' => 'The email must be a valid email address.',
                'email.unique' => 'The email has already been taken.',
                'password.min' => 'The password must be at least 8 characters.',
                'password.confirmed' => 'The password confirmation does not match.',
            ]);

            // Find the user
            $user = User::findOrFail($id);

            // Update the user's information
            $user->name = $validatedData['name'];
            $user->email = $validatedData['email'];

            // Update the password if provided
            if ($request->filled('password')) {
                $user->password = bcrypt($validatedData['password']);
            }

            // Save the changes
            $user->save();

            // Redirect to the user's profile page with a success message
            return redirect()->back()
                ->with('success', 'Sales Person updated successfully.');

        } catch (ValidationException $e) {
            return redirect()
                ->back()
                ->withErrors($e->errors())
                ->withInput();
        } catch (QueryException $e) {
            Log::error('Sales Person update failed: ' . $e->getMessage());
            return redirect()
                ->back()
                ->with('error', 'Database error occurred. Please try again.')
                ->withInput();
        } catch (\Exception $e) {
            Log::critical('Unexpected error in sales person update: ' . $e->getMessage());
            return redirect()
                ->back()
                ->with('error', 'An unexpected error occurred. Please contact support.')
                ->withInput();
        }
    }

    public function destroy($id)
    {
        try {
            $user = User::findOrFail($id);
            if (!$user) {
                return redirect()->back()->with('error', 'Sales Person not found.');
            }

            $user->delete();

            return redirect()->back()->with('success', 'Sales Person deleted successfully.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Failed to delete Sales Person. ' . $e->getMessage());
        }
    }

}
