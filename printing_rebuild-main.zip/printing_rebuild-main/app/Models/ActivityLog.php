<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ActivityLog extends Model
{
    protected $guarded = ['id'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function isDoing()
    {
        return $this->user->name . ' ' . $this->activity . ' ' . $this->object;
    }

    public function objectLink()
    {
        if(empty($this->object_id)) {
            return '#';
        }
        
        switch ($this->object) {
            case 'customer':
                return route('customers.index');
            case 'user':
                return route('users.index');
            case 'Post Press Subcon':
            case 'finishing_by':
                return route('finishing_bies.index');
            default:
                return '#';
        }
    }

    public function objectName()
    {
        switch ($this->object) {
            case 'customer':
                return optional(Customer::find($this->object_id))->company_name ?? 'Deleted Customer';
            case 'user':
                return optional(User::find($this->object_id))->name ?? 'Deleted User';
            case 'post-press subcon':
            case 'finishing_by':
                return optional(FinishingBy::find($this->object_id))->name ?? 'Deleted Item';
            default:
                return 'Unknown Object';
        }
    }

    public function timeOfActivity()
    {
        return $this->created_at->diffForHumans();
    }

}