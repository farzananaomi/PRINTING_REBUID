<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FinishingByDescription extends Model
{
    protected $guarded = ['id'];

    public function finishingBy()
    {
        return $this->belongsTo(FinishingBy::class);
    }
}
