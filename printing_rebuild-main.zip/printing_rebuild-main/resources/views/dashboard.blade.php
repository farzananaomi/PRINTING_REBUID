<x-layouts.app :title="__('Dashboard')">
    <div class="flex h-full w-full flex-1 flex-col gap-4 rounded-xl">
        <x-status-summary :counts="[
            'pending' => 42,
            'process_job' => 18,
            'urgent_job' => 23,
            'goods_ready' => 8,
            'completed' => 156,
            'on_hold' => 15,
            'canceled' => 3,
        ]" />

        <!-- Activity Log Card -->
        <div class="p-4 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
            <h3 class="mb-4 text-lg font-semibold text-gray-900 dark:text-white">Activity Log</h3>
            <div class="overflow-y-auto" style="height: 300px;">
                <ol class="relative border-s border-gray-200 dark:border-gray-700">
                    <!-- Example log items - you would loop through your actual data here -->
                    @foreach ($activityLogs as $activity )
                        
                        <li class="mb-5 ms-6">
                            <div class="items-center justify-between p-4 bg-white border border-gray-200 rounded-lg shadow-xs sm:flex dark:bg-gray-700 dark:border-gray-600">
                                <time class="mb-1 text-xs font-normal text-gray-400 sm:order-last sm:mb-0">{{ $activity->timeOfActivity() }}</time>
                                <div class="text-sm font-normal text-gray-500 dark:text-gray-300">{{ $activity->isDoing() }} <a href="{{ $activity->objectLink() }}" class="font-semibold text-blue-600 dark:text-blue-500 hover:underline">{{ $activity->objectName() }}</a> </div>
                            </div>
                        </li>

                    @endforeach
                </ol>
            </div>
        </div>

    </div>
</x-layouts.app>
