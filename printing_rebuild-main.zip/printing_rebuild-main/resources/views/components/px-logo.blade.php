<img 
    src="{{ asset('images/logo.svg') }}" 
    style="height: 150px; width: auto;"
    alt="Company Logo"
/>