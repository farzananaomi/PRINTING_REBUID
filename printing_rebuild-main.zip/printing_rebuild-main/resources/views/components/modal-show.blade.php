<!-- Modal Structure (keep this in your main layout file) -->
<div id="default-modal" tabindex="-1" aria-hidden="true"
    class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <!-- Backdrop -->
    <div class="fixed inset-0 bg-black/50 modal-backdrop"></div>

    <!-- Modal Container -->
    <div class="relative flex items-center justify-center w-full h-full min-h-screen p-4">
       <div class="relative w-full max-w-2xl max-h-full">
          <!-- Modal content -->
          <div class="relative bg-white rounded-lg shadow-sm dark:bg-gray-700">
             <!-- Modal header -->
             <div
                class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600 border-gray-200">
                <h3 id="modal-title" class="text-xl font-semibold text-gray-900 dark:text-white"></h3>
                <button type="button"
                       class="modal-close text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white">
                    <svg class="w-3 h-3" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                       <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                            stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
             </div>
             <!-- Modal body -->
             <div id="modal-content" class="p-4 md:p-5 space-y-4"></div>
          </div>
       </div>
    </div>
</div>

<script>
    // Enhanced Modal Controller with better SPA support
    document.addEventListener('DOMContentLoaded', function () {
       const modal = document.getElementById('default-modal');
       const backdrop = modal.querySelector('.modal-backdrop');

       // Close modal function
       const closeModal = () => {
          modal.classList.add('hidden');
          document.body.style.overflow = 'auto';
          document.getElementById('modal-content').innerHTML = '';
       };

       // Open modal function
       const openModal = (data) => {
          document.getElementById('modal-title').textContent = data.title || '';

          // Show loading state immediately
          document.getElementById('modal-content').innerHTML = `
          <div class="flex justify-center items-center h-32">
             <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 dark:border-gray-100"></div>
          </div>
       `;
          modal.classList.remove('hidden');
          document.body.style.overflow = 'hidden';

          if (data.url) {
             fetch(data.url)
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok');
                    return response.text();
                })
                .then(html => {
                    document.getElementById('modal-content').innerHTML = html;
                    initModalContent();
                })
                .catch(error => {
                    document.getElementById('modal-content').innerHTML = `
                    <div class="text-red-500 p-4">Error loading content: ${error.message}</div>
                `;
                });
          } else if (data.content) {
             document.getElementById('modal-content').innerHTML = data.content;
             initModalContent();
          }
       };

       // Initialize content inside modal
       function initModalContent() {
          // Initialize forms
          const forms = document.getElementById('modal-content').querySelectorAll('form');
          forms.forEach(form => {
             // Add form handling logic here
          });

          // Rebind modal triggers inside the modal content
          document.getElementById('modal-content').querySelectorAll('[data-modal-trigger]').forEach(trigger => {
             trigger.addEventListener('click', (e) => {
                e.preventDefault();
                openModal({
                    title: trigger.dataset.title || 'Modal',
                    url: trigger.dataset.url
                });
             });
          });
       }

       // Close handlers
       modal.querySelector('.modal-close').addEventListener('click', closeModal);
       backdrop.addEventListener('click', closeModal);

       // Escape key handler
       document.addEventListener('keydown', (e) => {
          if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
             closeModal();
          }
       });

       // Global modal controller
       window.Modal = {
          open: openModal,
          close: closeModal
       };

       // Event delegation for modal triggers
       function handleModalTriggers(e) {
          const trigger = e.target.closest('[data-modal-trigger]');
          if (trigger) {
             e.preventDefault();
             openModal({
                title: trigger.dataset.title || 'Modal',
                url: trigger.dataset.url
             });
          }
       }

       // Initial event binding
       document.body.addEventListener('click', handleModalTriggers);

       // SPA navigation support
       function reinitializeModalTriggers() {
          // Remove old listener to prevent duplicates
          document.body.removeEventListener('click', handleModalTriggers);
          // Add fresh listener
          document.body.addEventListener('click', handleModalTriggers);
       }

       // Mutation Observer for dynamic content (FluxUI)
       const observer = new MutationObserver(reinitializeModalTriggers);

       // Configuration for the observer
       const config = {
          childList: true,
          subtree: true
       };

       // Start observing the document body
       observer.observe(document.body, config);

       // Livewire support
       if (window.livewire) {
          window.livewire.hook('message.processed', reinitializeModalTriggers);
       }

       // Inertia.js support
       if (window.Inertia) {
          Inertia.on('success', reinitializeModalTriggers);
       }

       // Turbolinks support (if using)
       if (window.Turbolinks) {
          document.addEventListener('turbolinks:load', reinitializeModalTriggers);
       }
    });
</script>