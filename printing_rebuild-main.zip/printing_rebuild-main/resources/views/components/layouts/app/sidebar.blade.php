<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="dark">
    <head>
        @include('partials.head')
    </head>
    <body class="min-h-screen bg-white dark:bg-zinc-800">
        


        <flux:sidebar sticky stashable class="border-r border-zinc-200 bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-900">
            <flux:sidebar.toggle class="lg:hidden" icon="x-mark" />

            <a href="{{ route('dashboard') }}" class="mr-5 flex items-center space-x-2" wire:navigate>
                <span class="flex h-20 w-50 mb-1 items-center justify-center rounded-md">
                    <x-px-logo class="size-9 fill-current text-black dark:text-white" />
                </span>
            </a>

            <flux:navlist variant="outline">
                <flux:navlist.group :heading="__('Platform')" class="grid">
                    <flux:navlist.item icon="home" :href="route('dashboard')" :current="request()->routeIs('dashboard')" wire:navigate>
                        {{ __('Dashboard') }}
                    </flux:navlist.item>
                </flux:navlist.group>

                <flux:navlist.group expandable heading="System Management" class="grid"
                    :expanded="request()->routeIs('users.index', 'customers.index', 'sales_persons.index', 'finishing_bies.index')">
                    <flux:navlist.item icon="user" :href="route('users.index')" :current="request()->routeIs('users.index')" wire:navigate>
                        {{ __('Users') }}
                    </flux:navlist.item>
                    <flux:navlist.item icon="users" :href="route('customers.index')" :current="request()->routeIs('customers.index')" wire:navigate>
                        {{ __('Customers') }}
                    </flux:navlist.item>
                    {{-- <flux:navlist.item icon="user-circle" :href="route('sales_persons.index')" :current="request()->routeIs('sales_persons.index')" wire:navigate>
                        {{ __('Sales Persons') }}
                    </flux:navlist.item> --}}
                    <flux:navlist.item icon="building-office" :href="route('finishing_bies.index')" :current="request()->routeIs('finishing_bies.index')" wire:navigate>
                        {{ __('Post-Press Subcon') }}
                    </flux:navlist.item>
                </flux:navlist.group>
            </flux:navlist>


            

            <flux:spacer />


            

            <!-- Desktop User Menu -->
            <flux:dropdown position="bottom" align="start">
                <flux:profile
                    :name="auth()->user()->name"
                    :initials="auth()->user()->initials()"
                    icon-trailing="chevrons-up-down"
                />

                <flux:menu class="w-[220px]">
                    <flux:menu.radio.group>
                        <div class="p-0 text-sm font-normal">
                            <div class="flex items-center gap-2 px-1 py-1.5 text-left text-sm">
                                <span class="relative flex h-8 w-8 shrink-0 overflow-hidden rounded-lg">
                                    <span
                                        class="flex h-full w-full items-center justify-center rounded-lg bg-neutral-200 text-black dark:bg-neutral-700 dark:text-white"
                                    >
                                        {{ auth()->user()->initials() }}
                                    </span>
                                </span>

                                <div class="grid flex-1 text-left text-sm leading-tight">
                                    <span class="truncate font-semibold">{{ auth()->user()->name }}</span>
                                    <span class="truncate text-xs">{{ auth()->user()->email }}</span>
                                </div>
                            </div>
                        </div>
                    </flux:menu.radio.group>

                    <flux:menu.separator />

                    <flux:menu.radio.group>
                        <flux:menu.item :href="route('settings.profile')" icon="cog" wire:navigate>{{ __('Settings') }}</flux:menu.item>
                    </flux:menu.radio.group>

                    <flux:menu.separator />

                    <form method="POST" action="{{ route('logout') }}" class="w-full">
                        @csrf
                        <flux:menu.item as="button" type="submit" icon="arrow-right-start-on-rectangle" class="w-full">
                            {{ __('Log Out') }}
                        </flux:menu.item>
                    </form>
                </flux:menu>
            </flux:dropdown>
        </flux:sidebar>

        <!-- Mobile User Menu -->
        <flux:header class="lg:hidden">
            <flux:sidebar.toggle class="lg:hidden" icon="bars-2" inset="left" />

            <flux:spacer />

            <flux:dropdown position="top" align="end">
                <flux:profile
                    :initials="auth()->user()->initials()"
                    icon-trailing="chevron-down"
                />

                <flux:menu>
                    <flux:menu.radio.group>
                        <div class="p-0 text-sm font-normal">
                            <div class="flex items-center gap-2 px-1 py-1.5 text-left text-sm">
                                <span class="relative flex h-8 w-8 shrink-0 overflow-hidden rounded-lg">
                                    <span
                                        class="flex h-full w-full items-center justify-center rounded-lg bg-neutral-200 text-black dark:bg-neutral-700 dark:text-white"
                                    >
                                        {{ auth()->user()->initials() }}
                                    </span>
                                </span>

                                <div class="grid flex-1 text-left text-sm leading-tight">
                                    <span class="truncate font-semibold">{{ auth()->user()->name }}</span>
                                    <span class="truncate text-xs">{{ auth()->user()->email }}</span>
                                </div>
                            </div>
                        </div>
                    </flux:menu.radio.group>

                    <flux:menu.separator />

                    <flux:menu.radio.group>
                        <flux:menu.item :href="route('settings.profile')" icon="cog" wire:navigate>{{ __('Settings') }}</flux:menu.item>
                    </flux:menu.radio.group>

                    <flux:menu.separator />

                    <form method="POST" action="{{ route('logout') }}" class="w-full">
                        @csrf
                        <flux:menu.item as="button" type="submit" icon="arrow-right-start-on-rectangle" class="w-full">
                            {{ __('Log Out') }}
                        </flux:menu.item>
                    </form>
                </flux:menu>
            </flux:dropdown>
        </flux:header>

        {{ $slot }}

        @fluxScripts

        <!-- Named modal -->
        <flux:modal 
                name="dynamic-modal" 
                class="md:w-[42rem]"
                x-data="{ modalTitle: 'Modal', modalContent: '' }"
            >
                <div class="space-y-6">
                    <div>
                        <flux:heading size="lg" x-text="modalTitle"></flux:heading>
                    </div>
                    
                    <div x-html="modalContent"></div>
                </div>
            </flux:modal>
             
            <x-modal-show />
     <script>
        // Make the modal function available globally
        window.showDynamicModal = async function(options) {
            const { title, url } = options;
            
            // Show loading state
            const { value: result } = await Swal.fire({
                title: title,
                html: '<div class="flex justify-center items-center h-32"><div class="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 dark:border-gray-100"></div></div>',
                showConfirmButton: false,
                allowOutsideClick: true,
                didOpen: () => {
                    // Fetch content after modal opens
                    fetch(url)
                        .then(response => response.text())
                        .then(html => {
                            Swal.update({
                                html: html,
                                allowOutsideClick: true
                            });
                            initModalScripts();
                        })
                        .catch(error => {
                            Swal.fire({
                                title: 'Error',
                                html: `<div class="text-red-500">Error loading content: ${error.message}</div>`,
                                icon: 'error'
                            });
                        });
                }
            });
        };

        // Initialize scripts inside modal content
        function initModalScripts() {
            // Handle nested modal triggers
            document.querySelectorAll('[data-swal-trigger]').forEach(trigger => {
                trigger.addEventListener('click', (e) => {
                    e.preventDefault();
                    window.showDynamicModal({
                        title: trigger.dataset.title || 'Modal',
                        url: trigger.dataset.url
                    });
                });
            });
            
            // Initialize forms, etc.
            const forms = document.querySelectorAll('.swal2-html-container form');
            forms.forEach(form => {
                // Your form initialization logic
            });
        }

        // Event delegation that works with dynamic content
        document.addEventListener('click', function(e) {
            const trigger = e.target.closest('[data-swal-trigger]');
            if (trigger) {
                e.preventDefault();
                window.showDynamicModal({
                    title: trigger.dataset.title || 'Modal',
                    url: trigger.dataset.url
                });
            }
        });

        // Handle Livewire navigation
        if (window.livewire) {
            window.livewire.hook('message.processed', () => {
                initModalScripts();
            });
        }

        // Handle Inertia navigation
        if (window.Inertia) {
            Inertia.on('success', () => {
                initModalScripts();
            });
        }

        // Flash messages
        @if(session('success'))
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'success',
                title: '{{ session('success') }}',
                showConfirmButton: false,
                timer: 2000,
                timerProgressBar: true,
            });
        @endif

        @if(session('error'))
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'error',
                title: '{{ session('error') }}',
                showConfirmButton: false,
                timer: 2000,
                timerProgressBar: true,
            });
        @endif
        </script>

    @livewireScripts
    {{-- <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.13.5/dist/cdn.min.js" defer></script> --}}
    </body>
</html>
