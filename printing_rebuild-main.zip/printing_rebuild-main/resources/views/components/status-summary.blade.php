<div class="space-y-4">
  <!-- Top Row - 4 Cards (now matching bottom style) -->
  <div class="grid grid-cols-4 gap-4">
    @foreach([
        'pending' => 'blue',
        'process_job' => 'purple',
        'urgent_job' => 'yellow',
        'goods_ready' => 'orange'
    ] as $status => $color)
    <div class="bg-white p-5 rounded-xl border border-gray-200 shadow-sm transition-all duration-300 hover:shadow-md hover:border-{{$color}}-300 dark:bg-gray-800 dark:border-gray-700 dark:hover:border-{{$color}}-500 group">
      <div class="flex items-center justify-between">
        <span class="text-xs font-semibold text-{{$color}}-600 uppercase tracking-wider dark:text-{{$color}}-300">
          {{ str_replace('_', ' ', $status) }}
        </span>
        {{-- <span class="text-xs px-2 py-1 rounded-full bg-{{$color}}-100 text-{{$color}}-800 dark:bg-{{$color}}-900/50 dark:text-{{$color}}-300">
          {{ $counts[$status] ?? 0 }}
        </span> --}}
      </div>
      <div class="mt-3">
        <div class="text-2xl font-bold text-gray-800 dark:text-white group-hover:text-{{$color}}-600">
          {{ $counts[$status] ?? 0 }}
        </div>
        <div class="h-1.5 w-full bg-gray-200 rounded-full mt-2 dark:bg-gray-700">
          <div class="h-1.5 rounded-full bg-{{$color}}-500" style="width: {{ min(($counts[$status]/(array_sum($counts)+0.01))*100, 100) }}%"></div>
        </div>
      </div>
    </div>
    @endforeach
  </div>

  <!-- Bottom Row - 3 Cards -->
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    @foreach([
        'completed' => 'green',
        'on_hold' => 'emerald',
        'canceled' => 'red'
    ] as $status => $color)
    <div class="bg-white p-5 rounded-xl border border-gray-200 shadow-sm transition-all duration-300 hover:shadow-md hover:border-{{$color}}-300 dark:bg-gray-800 dark:border-gray-700 dark:hover:border-{{$color}}-500 group">
      <div class="flex items-center justify-between">
        <span class="text-xs font-semibold text-{{$color}}-600 uppercase tracking-wider dark:text-{{$color}}-300">
          {{ str_replace('_', ' ', $status) }}
        </span>
        {{-- <span class="text-xs px-2 py-1 rounded-full bg-{{$color}}-100 text-{{$color}}-800 dark:bg-{{$color}}-900/50 dark:text-{{$color}}-300">
          {{ $counts[$status] ?? 0 }}
        </span> --}}
      </div>
      <div class="mt-3">
        <div class="text-2xl font-bold text-gray-800 dark:text-white group-hover:text-{{$color}}-600">
          {{ $counts[$status] ?? 0 }}
        </div>
        <div class="h-1.5 w-full bg-gray-200 rounded-full mt-2 dark:bg-gray-700">
          <div class="h-1.5 rounded-full bg-{{$color}}-500" style="width: {{ min(($counts[$status]/(array_sum($counts)+0.01))*100, 100) }}%"></div>
        </div>
      </div>
    </div>
    @endforeach
  </div>
</div>