<div class="space-y-2 p-4 border rounded-lg">
    {{-- <h3 class="text-lg font-semibold">{{ $finishingBy->name }}</h3> --}}
    <div class="pl-4 space-y-1">
        @foreach($finishingBy->descriptions as $description)
            <p>{{ $description->description }}</p>
        @endforeach
    </div>
</div>